import {bitrateView} from "./bitrate-model.js";
import {audioPacketPoints, packetSeconds, frameTimePoints, frameTimeRange} from "./distribution-model.js";
import {formatBytes, formatBitrate, byteEvidence, byteLimit, quantityScale, quantityNumber, scalePlotData} from "./units.js";
import { parsePortable, makePortable, maxPortableBytes, utcFilename } from "./portable.js";
import { plot, gopOverview } from "./charts.js";
import { basicInfoHTML, initBasicInfo } from "./basic-info.js";
import {vmafModels} from "./vmaf.js";
import {
  parseCrfs,
  rowLabel,
  trialPlotData,
  trialFramePlotData,
  metricLabels,
  trialSortFields,
  sortTrialRows,
} from "./trial-model.js";
const modes = ["inspect", "compare", "trial"],
  reports = {},
  reportOwners = {},
  viewCharts = { inspect: [], compare: [], trial: [] };
let activeMode = "inspect",
  renderingMode = null,
  nav = null;
const modeOf = (r) => (r.type === "analyze" ? "inspect" : r.type);
const $ = (s) =>
    document.querySelector(
      /^#(result|result-title|summary|details|export)$/.test(s)
        ? "#" + (renderingMode || activeMode) + "-" + s.slice(1)
        : s,
    ),
  token = $("meta[name=token]").content;
let current = null,
  environmentReady = false,
  desktopSession = false,
  report = null,
  infoPath = null,
  hasVideo = false,
  charts = [],
  importing = false;
const esc = (v) =>
  String(v ?? "未报告").replace(
    /[&<>"']/g,
    (c) =>
      ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;", "'": "&#39;" })[
        c
      ],
  );
const fmt = (v, d = 3) =>
  typeof v === "number"
    ? v.toLocaleString("zh-CN", { maximumFractionDigits: d })
    : (v ?? "未报告");
const unitCell = Symbol('unit-cell');
const quantityCell = (text, title) => ({[unitCell]: true, text, title, toString: () => text});
const size = v => quantityCell(formatBytes(v), byteEvidence(v));
const rate = mbps => quantityCell(formatBitrate(mbps == null ? null : mbps * 1e6), mbps == null ? '未报告' : `${mbps * 1e6} bit/s`);
const cellHTML = v => v?.[unitCell] ? `<span title="${esc(v.title)}">${esc(v.text)}</span>` : esc(v);
const clean = (v) => v.trim().replace(/^"|"$/g, "");
for(const id of ['#vmaf-model','#trial-vmaf-model'])
  $(id).innerHTML=Object.entries(vmafModels).map(([version,m])=>`<option value="${version}">${esc(version)} · ${esc(m.label)}</option>`).join('');
async function api(url, options = {}) {
  const r = await fetch("/api/" + url, {
      ...options,
      headers: {
        "Content-Type": "application/json",
        "X-MediaScope-Token": token,
      },
    }),
    d = await r.json();
  if (!r.ok) throw Error(d.error || "请求失败");
  return d;
}
function showStartup(s) {
  environmentReady = !s.startup || s.startup.state === "ready";
  desktopSession = !!s.desktop;
  const status = $("#startup-status");
  status.textContent = s.startup?.message || "运行环境已就绪";
  status.classList.toggle("hidden", environmentReady);
  status.classList.toggle("error", s.startup?.state === "error");
  $("#environment").textContent = environmentReady ? s.versions.ffmpeg : status.textContent;
  for (const box of document.querySelectorAll("[name=metric]")) {
    box.disabled = !environmentReady || !s.metrics.includes(box.value);
    if (environmentReady && box.disabled) box.checked = false;
  }
}
window.addEventListener("beforeunload", (event) => {
  if (desktopSession && latestJobs.some((j) => ["queued", "running"].includes(j.status))) {
    event.preventDefault();
    event.returnValue = "任务尚未完成，退出将停止分析。";
  }
});
function progressValue(value) {
  return Number.isFinite(value)
    ? value.toLocaleString("zh-CN", { maximumFractionDigits: 2 })
    : null;
}
function elapsed(startedAt) {
  const seconds = Math.max(
    0,
    Math.floor((Date.now() - new Date(startedAt).getTime()) / 1000),
  );
  if (!Number.isFinite(seconds)) return "";
  const h = Math.floor(seconds / 3600),
    m = Math.floor((seconds % 3600) / 60),
    s = seconds % 60;
  return `已运行 ${h ? String(h).padStart(2, "0") + ":" : ""}${String(m).padStart(2, "0")}:${String(s).padStart(2, "0")}`;
}
function message(
  text,
  error = false,
  progress = null,
  startedAt = null,
  status = null,
) {
  $("#task").classList.remove("hidden");
  $("#task").classList.toggle("error", error);
  $("#task-label").textContent = error
    ? "任务未完成"
    : status === "cancelled"
      ? "任务已取消"
      : status === "done"
        ? "任务完成"
        : "分析任务";
  $("#task-message").textContent = text;
  $("#cancel").classList.toggle("hidden", !current);
  const details = $("#task-progress-details"),
    stage = $("#task-stage"),
    phase = $("#task-phase");
  details.classList.toggle("hidden", !progress);
  stage.classList.toggle("hidden", !progress?.stage);
  phase.classList.toggle(
    "hidden",
    !(progress?.phaseIndex != null && progress?.phaseCount),
  );
  if (!progress) {
    stage.textContent = "";
    phase.textContent = "";
    syncTaskBrief();
    return;
  }
  stage.textContent = progress.stage || "";
  phase.textContent =
    progress.phaseIndex != null && progress.phaseCount
      ? `阶段 ${progress.phaseIndex} / ${progress.phaseCount}`
      : "";
  const determinate =
      Number.isFinite(progress.completed) &&
      Number.isFinite(progress.total) &&
      progress.total >= 0,
    percent = determinate
      ? progress.total === 0
        ? 100
        : Math.max(
            0,
            Math.min(100, (progress.completed / progress.total) * 100),
          )
      : null;
  const count = progressValue(progress.completed),
    total = progressValue(progress.total);
  $("#task-count").textContent =
    count === null
      ? "正在处理"
      : total === null
        ? `已处理 ${count}${progress.unit ? " " + progress.unit : ""}`
        : `${count} / ${total}${progress.unit ? " " + progress.unit : ""}`;
  $("#task-percent").textContent =
    percent === null
      ? "总量待核验"
      : `${percent.toFixed(percent < 10 && percent % 1 ? 1 : 0)}%`;
  const track = $("#task-progress-track"),
    bar = $("#task-progress-bar"),
    islandBar = $("#island-progress-bar");
  track.classList.toggle("indeterminate", !determinate);
  if (!bar.style) bar.style = {};
  bar.style.width = determinate ? percent + "%" : "";
  if (islandBar) islandBar.style.width = determinate ? percent + "%" : "";
  track.ariaValueNow = determinate ? String(percent) : "";
  track.ariaValueMax = determinate ? "100" : "";
  const subtasks = Object.values(progress.subtasks || {});
  $("#task-subtasks").innerHTML = subtasks
    .map((item) => {
      const done = progressValue(item.completed),
        all = progressValue(item.total);
      return `<div class="task-subtask"><span>${esc(item.label || "并行任务")}</span><span>${done ?? "准备中"}${all !== null ? " / " + all : ""}${item.unit ? " " + esc(item.unit) : ""}</span></div>`;
    })
    .join("");
  $("#task-elapsed").textContent = startedAt ? elapsed(startedAt) : "";
  syncTaskBrief();
}
function busy(value) {
  $("#analyze").disabled = !environmentReady || !infoPath || !hasVideo;
  for (const id of ["inspect", "enqueue-analyze", "compare", "enqueue-compare", "trial", "enqueue-trial"])
    if ($("#" + id)) $("#" + id).disabled = !environmentReady;
  $("#import-report").disabled = value;
  $("#import-button").disabled = value;
}
let submitting = false,
  refreshing = false,
  autoOpen = null,
  queueView = "",
  historyView = "",
  resultView = "",
  latestJobs = [],
  importSequence = 0;
let importedResults = [],
  removedReportIds = new Set(),
  selectedResults = new Set(),
  selectedPlans = new Set(),
  downloadNames = new Map();
async function launch(data) {
  if (submitting) return;
  submitting = true;
  try {
    const j = await api("jobs", { method: "POST", body: JSON.stringify(data) });
    latestJobs.push({ id: j.id, status: "queued" });
    if (!data.enqueue) autoOpen = j.id;
    message(data.enqueue ? "已加入队列，参数已保存" : "任务已提交");
    await poll();
  } catch (e) {
    message(e.message, true);
  } finally {
    submitting = false;
  }
}
const fileName = (file) =>
  String(file || "未指定文件")
    .split(/[\\/]/)
    .pop();
function queueRow(j, position) {
  const names = {
      inspect: "读取信息",
      analyze: "完整分析",
      compare: "质量比较",
      trial: "片段实验",
    },
    states = {
      queued: "等待",
      running: "运行中",
      done: "完成",
      error: "失败",
      cancelled: "已取消",
    };
  const primary = fileName(j.file || j.reference),
    secondary = j.candidate ? " → " + fileName(j.candidate) : "";
  const pathText =
    (j.file || j.reference || "") + (j.candidate ? " → " + j.candidate : "");
  const action = ["done", "error"].includes(j.status) ? "retry" : j.status === "queued" ? "remove" : "cancel";
  const label = { retry: "重新排队", cancel: "取消", remove: "移除" }[action];
  const stage =
    j.status === "running" ? j.progress?.stage || j.message : j.message;
  return `<div class="queue-item">${j.status === "queued" ? `<input class="portable-check" type="checkbox" data-plan-select="${j.id}" aria-label="选择任务计划 ${esc(primary)}" ${selectedPlans.has(j.id) ? "checked" : ""}>` : ""}<div class="queue-item-main"><strong>${position ? position + ". " : ""}${esc(primary + secondary)}</strong><span class="queue-state">${esc(names[j.type])} · ${states[j.status]}</span><p class="queue-path" title="${esc(pathText)}">${esc(pathText)}</p><p class="queue-description">${esc(j.description || "")}${stage ? " · " + esc(stage) : ""}</p></div><div class="queue-actions"><button class="secondary" data-job="${j.id}" data-action="${j.status === 'done' ? 'report' : action}">${j.status === 'done' ? '查看报告' : label}</button>${j.status === 'done' ? `<button class="secondary" data-job="${j.id}" data-action="retry">重新排队</button>` : ''}${["done", "error"].includes(j.status) ? `<button class="secondary" data-job="${j.id}" data-action="remove">移除</button>` : ''}</div></div>`;
}
function resultItems() {
  return [
    ...latestJobs
      .filter((j) => j.status === "done")
      .map((j) => ({ id: j.id, job: j })),
    ...importedResults,
  ];
}
function renderResultList() {
  const items = resultItems(),
    available = new Set(items.map((x) => x.id));
  let viewRemoved = false;
  for (const mode of modes) {
    if (reportOwners[mode] && removedReportIds.has(reportOwners[mode])) {
      viewCharts[mode].forEach(chart => chart.dispose?.());
      viewCharts[mode] = [];
      delete reports[mode];
      delete reportOwners[mode];
      $("#" + mode + "-details").textContent = "";
      $("#" + mode + "-summary").textContent = "";
      viewRemoved = true;
    }
  }
  removedReportIds.clear();
  if (viewRemoved) switchMode(activeMode);
  for (const id of selectedResults)
    if (!available.has(id)) selectedResults.delete(id);
  $("#result-clear").disabled = !items.length;
  const signature = JSON.stringify(items.map((x) => [x.id, x.job?.status]));
  if (signature === resultView) return;
  resultView = signature;
  $("#result-list").innerHTML =
    items
      .map((x) => {
        const r = x.report,
          j = x.job,
          type = r?.type || j?.type || "?",
          file =
            r?.file ||
            r?.source?.file ||
            r?.reference?.file ||
            j?.file ||
            j?.reference ||
            "未指定文件",
          other = r?.candidate?.file || j?.candidate;
        const label = fileName(file) + (other ? " → " + fileName(other) : "");
        return `<div class="queue-item"><input class="portable-check" type="checkbox" data-result-select="${esc(x.id)}" aria-label="选择结果 ${esc(label)}" ${selectedResults.has(x.id) ? "checked" : ""}><div class="queue-item-main"><strong>${esc(label)}</strong><span class="queue-state">${esc(type)} · ${r ? "已导入" : "已完成"}</span><p class="queue-path">${esc(file)}${other ? " → " + esc(other) : ""}</p></div><div class="queue-actions"><button class="secondary" data-result-open="${esc(x.id)}">查看报告</button><button class="secondary" data-result-remove="${esc(x.id)}">移除</button></div></div>`;
      })
      .join("") || '<p class="hint">暂无已完成结果。</p>';
}
$("#queue-list").onchange = (e) => {
  const id = e.target.dataset?.planSelect;
  if (id) {
    if (e.target.checked) selectedPlans.add(id);
    else selectedPlans.delete(id);
  }
};
$("#result-list").onchange = (e) => {
  const id = e.target.dataset?.resultSelect;
  if (id) {
    if (e.target.checked) selectedResults.add(id);
    else selectedResults.delete(id);
  }
};
$("#result-list").onclick = async (e) => {
  const remove = e.target.closest?.("[data-result-remove]");
  if (remove) {
    remove.disabled = true;
    try {
      const id = remove.dataset.resultRemove;
      if (importedResults.some(x => x.id === id)) importedResults = importedResults.filter(x => x.id !== id);
      else await api("jobs/" + id, { method: "DELETE" });
      removedReportIds.add(id);
      renderResultList();
      await poll();
    } catch (err) { message(err.message, true); remove.disabled = false; }
    return;
  }
  const id = e.target.closest?.("[data-result-open]")?.dataset.resultOpen;
  if (!id) return;
  try {
    const item = resultItems().find((x) => x.id === id);
    if (!item) throw Error("结果已不可用");
    render(item.report || (await api("jobs/" + id + "/report")), true, id);
  } catch (err) {
    message(err.message, true);
  }
};
async function queueAction(event) {
  const button = event.target.closest("[data-job]");
  if (!button) return;
  button.disabled = true;
  try {
    if (button.dataset.action === "report")
      render(await api("jobs/" + button.dataset.job + "/report"), true, button.dataset.job);
    else if (button.dataset.action === "retry")
      await api("jobs/" + button.dataset.job + "/retry", {
        method: "POST",
        body: "{}",
      });
    else {
      await api("jobs/" + button.dataset.job, { method: "DELETE" });
      removedReportIds.add(button.dataset.job);
    }
    await poll();
  } catch (e) {
    message(e.message, true);
    button.disabled = false;
  }
}
$("#queue-list").onclick = queueAction;
$("#queue-history-list").onclick = queueAction;
for (const [id, scope] of [["queue-clear", "queued"], ["queue-history-clear", "history"], ["result-clear", "results"]]) {
  $("#" + id).onclick = async (event) => {
    const button = event.currentTarget;
    button.disabled = true;
    try {
      const removedIds = latestJobs.filter(j => scope === "queued" ? j.status === "queued" : scope === "results" ? j.status === "done" : ["done", "error"].includes(j.status)).map(j => j.id);
      if (scope === "results") removedIds.push(...importedResults.map(x => x.id));
      await api("jobs/clear", { method: "POST", body: JSON.stringify({ scope }) });
      removedIds.forEach(id => removedReportIds.add(id));
      if (scope === "results") importedResults = [];
      renderResultList();
      await poll();
    } catch (e) { message(e.message, true); button.disabled = false; }
  };
}
async function poll() {
  if (refreshing) return;
  refreshing = true;
  try {
    const previous = current,
      s = await api("status"),
      running = s.jobs.find((j) => j.status === "running");
    showStartup(s);
    current = running?.id ?? null;
    latestJobs = s.jobs;
    const pending = s.jobs.filter((j) =>
        ["queued", "running"].includes(j.status),
      ),
      history = s.jobs.filter((j) => ["done", "error"].includes(j.status));
    const waitingIds = new Set(
      pending.filter((j) => j.status === "queued").map((j) => j.id),
    );
    for (const id of selectedPlans)
      if (!waitingIds.has(id)) selectedPlans.delete(id);
    $("#queue-count").textContent =
      (s.queueRunning ? "运行中" : "已暂停 / 待开始") +
      " · " +
      pending.filter((j) => j.status === "queued").length +
      " 项等待";
    $("#queue-start").disabled = !environmentReady || !s.jobs.some((j) => j.status === "queued");
    $("#queue-pause").disabled = !s.queueRunning;
    $("#queue-clear").disabled = !waitingIds.size;
    $("#queue-history-clear").disabled = !history.length;
    $("#queue-history-count").textContent = `已结束任务（${history.length}）`;
    const nextQueue = JSON.stringify(
      pending.map((j) => [j.id, j.status, j.progress?.stage]),
    );
    const nextHistory = JSON.stringify(history.map((j) => [j.id, j.status]));
    if (nextQueue !== queueView) {
      $("#queue-list").innerHTML =
        pending.map((j, i) => queueRow(j, i + 1)).join("") ||
        '<p class="hint">暂无待运行任务。设置文件后点击“加入队列”。</p>';
      queueView = nextQueue;
    }
    if (nextHistory !== historyView) {
      $("#queue-history-list").innerHTML = history
        .map((j) => queueRow(j))
        .join("");
      historyView = nextHistory;
    }
    renderResultList();
    const completed = s.jobs.find(
      (j) => j.id === autoOpen && !["queued", "running"].includes(j.status),
    );
    if (completed) {
      autoOpen = null;
      if (completed.status === "done")
        render(await api("jobs/" + completed.id + "/report"), false, completed.id);
      if (!running)
        message(
          completed.retentionMessage || completed.message,
          completed.status === "error",
          completed.progress,
          completed.startedAt,
          completed.status,
        );
    }
    const ended = s.jobs.find(
      (j) => j.id === previous && !["queued", "running"].includes(j.status),
    );
    if (autoOpen && !s.jobs.some(j => j.id === autoOpen)) autoOpen = null;
    if (previous && !running && !s.jobs.some(j => j.id === previous)) message("任务已取消并移除", false, null, null, "cancelled");
    if (ended && ended.status === "error")
      $("#queue-history").open = true;
    if (!running && ended)
      message(
        ended.message,
        ended.status === "error",
        ended.progress,
        ended.startedAt,
        ended.status,
      );
    if (running)
      message(
        running.progress?.detail || running.message,
        false,
        running.progress,
        running.startedAt,
        running.status,
      );
    $("#cancel").classList.toggle("hidden", !current);
    busy(!!current || importing);
  } catch (e) {
    message(e.message, true);
  } finally {
    refreshing = false;
  }
}
for (const action of ["start", "pause"])
  $("#queue-" + action).onclick = async () => {
    try {
      await api("queue", { method: "POST", body: JSON.stringify({ action }) });
      await poll();
    } catch (e) {
      message(e.message, true);
    }
  };
setInterval(poll, 1000);
$("#cancel").onclick = async () => {
  try {
    await api("jobs/" + current, { method: "DELETE" });
  } catch (e) {
    message(e.message, true);
  }
};
function switchMode(mode) {
  activeMode = mode;
  report = reports[mode] ?? null;
  charts = viewCharts[mode];
  document
    .querySelectorAll(".tab")
    .forEach((t) => t.classList.toggle("selected", t.dataset.mode === mode));
  for (const name of modes) {
    document
      .querySelector("#" + name + "-panel")
      .classList.toggle("hidden", name !== mode);
    document
      .querySelector("#" + name + "-result")
      .classList.toggle("hidden", name !== mode || !reports[name]);
  }
  updateNav();
}
document
  .querySelectorAll(".tab")
  .forEach((b) => (b.onclick = () => switchMode(b.dataset.mode)));
document.querySelectorAll(".file-picker").forEach(
  (button) =>
    (button.onclick = async () => {
      button.disabled = true;
      const label = button.textContent;
      button.textContent = "正在打开…";
      message(
        "正在打开 Windows 文件选择器；如果没有出现在前台，请查看任务栏。",
      );
      try {
        const result = await api("select-file", { method: "POST", body: "{}" });
        if (result.file) {
          const input = $("#" + button.dataset.target);
          input.value = result.file;
          input.dispatchEvent(new Event("input"));
          message("已选择文件：" + result.file);
        } else message("已取消选择文件");
      } catch (e) {
        message(
          e.message === "Failed to fetch"
            ? "本机分析服务未运行，请重新启动 MediaScope"
            : e.message,
          true,
        );
      } finally {
        button.textContent = label;
        button.disabled = false;
      }
    }),
);
$("#file").oninput = () => {
  infoPath = null;
  $("#analyze").disabled = true;
};
const syncSitiWorkers = () => {
  $("#siti-device").disabled = !$("#complexity").checked;
  $("#siti-workers").disabled = !$("#complexity").checked || $("#siti-device").value === "gpu";
};
$("#complexity").onchange = syncSitiWorkers;
let sitiGpuCheck;
$("#siti-device").onchange = async () => {
  syncSitiWorkers();
  if ($("#siti-device").value !== "gpu") return;
  $("#siti-device-status").textContent = "正在检查 GPU 并执行 SI/TI 数值自检…";
  try {
    const result = await (sitiGpuCheck ??= api("siti-gpu"));
    $("#siti-device-status").textContent = result.available
      ? `GPU：${result.device}；数值自检通过。完整逐帧计算，软件解码；运行失败回退 CPU，报告记录原因。`
      : `GPU 不可用：${result.reason}。已选择 CPU。`;
    if (!result.available) {
      $("#siti-device").value = "cpu";
      $("#siti-device option[value=gpu]").disabled = true;
      syncSitiWorkers();
    }
  } catch (e) {
    sitiGpuCheck = null;
    $("#siti-device-status").textContent = `GPU 检查失败：${e.message}。运行时重新检查，失败回退 CPU。`;
  }
};
syncSitiWorkers();
$("#inspect").onclick = async () => {
  const requested = clean($("#file").value);
  try {
    message("正在读取文件信息…");
    const result = await api("probe", {
      method: "POST",
      body: JSON.stringify({ file: requested }),
    });
    if (clean($("#file").value) === requested) $("#file").value = result.file;
    render(result);
  } catch (e) {
    message(e.message, true);
  }
};
$("#analyze").onclick = () =>
  launch({
    type: "analyze",
    file: infoPath,
    stream: Number($("#stream").value),
    complexity: $("#complexity").checked,
    bitrateWindowMs: Number($("#bitrate-window").value),
    sitiWorkers: $("#siti-workers").value,
    sitiDevice: $("#siti-device").value,
  });
$("#compare").onclick = (event) => {
  const input = {
    type: "compare",
    reference: clean($("#reference").value),
    candidate: clean($("#candidate").value),
    refStream: Number($("#refStream").value),
    candidateStream: Number($("#candidateStream").value),
    comparisonMode: $("#comparison-mode").value,
    timingMode: $("#timing-mode").value,
    metrics: [...document.querySelectorAll("[name=metric]:checked")].map(
      (x) => x.value,
    ),
    confirm: $("#confirm").checked,
  };
  if(input.metrics.includes('vmaf'))input.vmafModel=$('#vmaf-model').value;
  if (input.timingMode === "ordinal-confirmed") {
    if (!$("#timing-confirm").checked) {
      message(
        "请确认两路视频的每个显示帧按顺序一一对应，且没有丢帧、重复帧或重排。",
        true,
      );
      return;
    }
    input.timingConfirmed = true;
  }
  if (input.timingMode === "playback-sample") {
    if (!$("#playback-confirm").checked) {
      message(
        "请确认两路首帧对应同一播放时刻，并接受 CFR 一侧作为采样网格的实验性解释。",
        true,
      );
      return;
    }
    input.playbackConfirmed = true;
  }
  if ($("#chroma-confirm-mode").checked) {
    if (!$("#chroma-confirm").checked) {
      message("请先确认色度位置来自可信来源，并了解结果依赖此假设。", true);
      return;
    }
    input.chromaConfirmed = true;
    input.chromaAssumptions = {};
    for (const [side, id] of [
      ["reference", "#reference-chroma"],
      ["candidate", "#candidate-chroma"],
    ])
      if ($(id).value) input.chromaAssumptions[side] = $(id).value;
  }
  launch({ ...input, enqueue: event?.currentTarget?.id === "enqueue-compare" });
};
$("#enqueue-compare").onclick = $("#compare").onclick;
$("#enqueue-analyze").onclick = () =>
  launch({
    type: "analyze",
    enqueue: true,
    file: clean($("#file").value),
    stream:
      infoPath === clean($("#file").value) ? Number($("#stream").value) : null,
    complexity: $("#complexity").checked,
    bitrateWindowMs: Number($("#bitrate-window").value),
    sitiWorkers: $("#siti-workers").value,
    sitiDevice: $("#siti-device").value,
  });
$("#enqueue-trial").onclick = () => {
  try {
    launch({ ...trialInput(), enqueue: true });
  } catch (e) {
    message(e.message, true);
  }
};
$("#chroma-confirm-mode").onchange = () =>
  $("#chroma-assumption-controls").classList.toggle(
    "hidden",
    !$("#chroma-confirm-mode").checked,
  );
$("#timing-mode").onchange = () => {
  $("#timing-confirm-row").classList.toggle(
    "hidden",
    $("#timing-mode").value !== "ordinal-confirmed",
  );
  $("#playback-confirm-row").classList.toggle(
    "hidden",
    $("#timing-mode").value !== "playback-sample",
  );
};
function trialInput() {
  return {
    type: "trial",
    file: clean($("#trial-file").value),
    stream: Number($("#trial-stream").value),
    start: Number($("#trial-start").value),
    duration: Number($("#trial-duration").value),
    encoder: $("#trial-encoder").value,
    depthMode: $("#trial-depth").value,
    presets: [...document.querySelectorAll("[name=trial-preset]:checked")].map(
      (x) => x.value,
    ),
    cpuUsed: Number($("#trial-cpu").value),
    crfs: parseCrfs($("#trial-crfs").value),
    metrics: $("#trial-vmaf").checked
      ? ["psnr", "ssim", "vmaf"]
      : ["psnr", "ssim"],
    ...($("#trial-vmaf").checked ? {vmafModel:$('#trial-vmaf-model').value} : {}),
    keepFiles: $("#trial-keep").checked,
    ...($("#trial-keep").checked ? {exportDirectory: clean($("#trial-save-directory").value)} : {}),
  };
}
function trialControls() {
  const av1 = $("#trial-encoder").value === "libaom-av1",
    both = $("#trial-depth").value === "both";
  $("#trial-presets").classList.toggle("hidden", av1);
  $("#trial-cpu-label").classList.toggle("hidden", !av1);
  try {
    const input = trialInput(),
      p = av1 ? 1 : input.presets.length,
      points = input.crfs.length * p * (both ? 2 : 1);
    $("#trial-count").textContent =
      `${input.crfs.length} 个 CRF × ${p} 个预设 × ${both ? 2 : 1} 种位深 = ${points} 个编码点。${points > 64 ? "超过 64 点上限，请减少选项。" : p < 1 || p > 4 ? "请选择 1–4 个 preset。" : "顺序运行，耗时曲线仅代表本机本次实验。"}`;
  } catch (e) {
    $("#trial-count").textContent = e.message;
  }
}
for (const id of ["trial-encoder", "trial-depth", "trial-crfs", "trial-cpu"])
  $("#" + id).addEventListener("input", trialControls);
document
  .querySelectorAll("[name=trial-preset]")
  .forEach((x) => x.addEventListener("change", trialControls));
trialControls();
$("#trial").onclick = () => {
  try {
    launch(trialInput());
  } catch (e) {
    message(e.message, true);
  }
};
function timestamp() {
  return utcFilename();
}
function safeName(value) {
  return (
    String(value || "media")
      .replace(/\.[^.\\/]+$/, "")
      .replace(/[<>:"/\\|?*\x00-\x1f]/g, "_")
      .replace(/[. ]+$/, "")
      .slice(0, 64) || "media"
  );
}
function reportName(r) {
  const first = r.file || r.source?.file || r.reference?.file,
    second = r.candidate?.file,
    media =
      safeName(fileName(first)) +
      (second ? "_vs_" + safeName(fileName(second)) : "");
  return `MediaScope-${r.type}-${media.slice(0, 100)}-${timestamp()}.json`;
}
function downloadPortable(results, plans, name) {
  const json = JSON.stringify(makePortable({ results, plans }), null, 2);
  if (new Blob([json]).size > maxPortableBytes)
    throw Error(`导出文件超过 ${byteLimit(maxPortableBytes)}；请勾选较少的结果，确保文件能够重新导入`);
  download(json, name, "application/json");
}
for (const mode of modes)
  document.querySelector("#" + mode + "-export").onclick = () => {
    const saved = reports[mode];
    if (saved)
      try {
        downloadPortable(
          [{ entryId: "current-report", report: saved }],
          [],
          reportName(saved),
        );
      } catch (e) {
        message(e.message, true);
      }
  };
function syncPortableControls() {
  const hasResults = $("#import-results").checked,
    hasPlans = $("#import-plans").checked;
  for (const id of ["#import-results-mode", "#import-results-mode-label"])
    $(id).classList.toggle("hidden", !hasResults);
  for (const id of [
    "#import-plan-mode",
    "#import-plan-mode-label",
    "#import-start-label",
  ])
    $(id).classList.toggle("hidden", !hasPlans);
}
$("#import-results").onchange = syncPortableControls;
$("#import-plans").onchange = syncPortableControls;
syncPortableControls();
async function portableExport() {
  const resultScope = $("#export-result-scope").value || "all",
    planScope = $("#export-plan-scope").value || "none",
    results = [],
    plans = [];
  if (resultScope === "current") {
    if (!report) throw Error("请先打开一份报告");
    results.push({ entryId: "current-report", report });
  } else if (resultScope !== "none") {
    const chosen = resultItems().filter(
      (item) => resultScope === "all" || selectedResults.has(item.id),
    );
    if (resultScope === "selected" && chosen.length !== selectedResults.size)
      throw Error("勾选的结果已变化，请重新确认导出范围");
    const ids = chosen.filter(item => !item.report).map(item => item.id);
    const hold = ids.length ? await api("local-data/export-hold", {method:"POST",body:JSON.stringify({ids})}) : null;
    try {
      for (const item of chosen)
        results.push({entryId:item.id,report:item.report || (await api("jobs/" + item.id + "/report"))});
    } finally {
      if (hold) await api("local-data/export-release", {method:"POST",body:JSON.stringify({key:hold.key})});
    }
  }
  if (planScope !== "none") {
    const saved = await api("plans"),
      chosen = saved.plans.filter(
        (item) => planScope === "all" || selectedPlans.has(item.entryId),
      );
    if (planScope === "selected" && chosen.length !== selectedPlans.size)
      throw Error("勾选的待运行任务已变化，请重新确认导出范围");
    plans.push(...chosen);
  }
  if (!results.length && !plans.length)
    throw Error("当前选择没有可导出的结果或计划");
  const name =
    resultScope === "current" && !plans.length
      ? reportName(report)
      : `MediaScope-${results.length && plans.length ? "bundle" : results.length ? "queue" : "plan"}-${timestamp()}.json`;
  downloadPortable(results, plans, name);
}
$("#export-portable").onclick = async () => {
  const button = $("#export-portable");
  button.disabled = true;
  try {
    await portableExport();
  } catch (e) {
    message(e.message, true);
  } finally {
    button.disabled = false;
  }
};
$("#import-button").onclick = () => $("#import-report").click();
$("#import-report").onchange = async (e) => {
  const input = e.target,
    f = input.files[0];
  if (!f) return;
  if (current || importing) {
    input.value = "";
    return;
  }
  importing = true;
  busy(true);
  message("正在读取并校验 JSON…");
  try {
    if (f.size > maxPortableBytes)
      throw Error(`JSON 文件超过 ${byteLimit(maxPortableBytes)} 导入上限`);
    const useResults = $("#import-results").checked,
      usePlans = $("#import-plans").checked;
    if (!useResults && !usePlans) throw Error("请至少选择一项导入内容");
    const saved = await f.text();
    if (current) throw Error("分析任务正在运行，请在任务完成后导入");
    const data = parsePortable(saved),
      results = useResults ? data.results : [],
      plans = usePlans ? data.plans : [];
    if (!results.length && !plans.length)
      throw Error("文件中没有所选的可导入内容");
    if (results.length === 1 && !plans.length) {
      const shown = results[0].report,
        previous = reports[modeOf(shown)];
      try {
        render(shown);
      } catch (err) {
        if (previous) render(previous);
        else
          document
            .querySelector("#" + modeOf(shown) + "-result")
            .classList.add("hidden");
        throw Error("报告无法完整显示：" + err.message);
      }
    }
    if (plans.length)
      await api("plans/import", {
        method: "POST",
        body: JSON.stringify({
          plans,
          mode: $("#import-plan-mode").value || "append",
          start: !!$("#import-start").checked,
        }),
      });
    if (results.length) {
      const incoming = results.map((item) => ({
        id: `imported-${Date.now()}-${++importSequence}`,
        report: item.report,
      }));
      if (($("#import-results-mode").value || "append") === "replace") {
        for (const item of importedResults) selectedResults.delete(item.id);
        importedResults = [];
      }
      importedResults.push(...incoming);
      if (results.length === 1 && !plans.length) reportOwners[modeOf(results[0].report)] = incoming[0].id;
      resultView = "";
      renderResultList();
    }
    if (results.length === 1 && !plans.length)
      switchMode(modeOf(results[0].report));
    await poll();
    message(
      `已导入 ${f.name}：${results.length} 份结果、${plans.length} 项计划。结果使用保存的原始数据，不重新计算。`,
    );
  } catch (err) {
    message(err.message, true);
  } finally {
    importing = false;
    busy(!!current);
    input.value = "";
  }
};


function download(text, name, type) {
  const count = downloadNames.get(name) || 0;
  downloadNames.set(name, count + 1);
  const unique = count
    ? name.replace(/(\.[^.]+)$/, (extension) => `-${count + 1}${extension}`)
    : name;
  const url = URL.createObjectURL(new Blob([text], { type })),
    a = document.createElement("a");
  a.href = url;
  a.download = unique;
  document.body.append(a);
  a.click();
  a.remove();
  setTimeout(() => URL.revokeObjectURL(url), 60000);
}
function cardsHTML(items) {
  return items
    .map(
      ([k, v]) =>
        `<div class="card"><span>${esc(k)}</span><strong>${cellHTML(v)}</strong></div>`,
    )
    .join("");
}
function cards(items) {
  $("#summary").innerHTML = cardsHTML(items);
}
function section(title, html) {
  return `<section class="section"><h3>${esc(title)}</h3>${html}</section>`;
}
function table(headers, rows) {
  return `<div class="table-wrap"><table><thead><tr>${headers.map((v) => `<th>${esc(v)}</th>`).join("")}</tr></thead><tbody>${rows.map((r) => `<tr>${r.map((v) => `<td>${cellHTML(v)}</td>`).join("")}</tr>`).join("")}</tbody></table></div>`;
}
function raw(data, title = "展开证据 / 原始数据") {
  return `<details><summary>${esc(title)}</summary><pre>${esc(JSON.stringify(data, null, 2))}</pre></details>`;
}
function notices(items) {
  return (items || []).map((w) => `<p class="notice">${esc(w)}</p>`).join("");
}
function draw(id, data, options) {
  const host = $("#" + id);
  if (host) {
    const p = plot(host, data, options);
    if (p) charts.push(p);
    return p;
  }
}
function render(r, activate = true, owner = null) {
  const mode = modeOf(r);
  renderingMode = mode;
  charts = viewCharts[mode];
  charts.forEach((c) => c.dispose?.());
  charts = [];
  try {
    $("#result-title").textContent =
      r.type === "compare"
        ? "质量对比报告"
        : r.type === "trial"
          ? "片段率失真实验"
          : "媒体分析报告";
    if (r.type === "compare") renderComparison(r);
    else if (r.type === "trial") renderTrial(r);
    else renderMedia(r);
    reports[mode] = r;
    reportOwners[mode] = owner;
  } finally {
    viewCharts[mode] = charts;
    renderingMode = null;
    switchMode(activate ? mode : activeMode);
    busy(!!current || importing);
  }
}
function renderMedia(r) {
  const displayControl = (curve, id) => curve ? `<div class="bitrate-display-control"><label for="${id}">显示窗口</label><select id="${id}">${curve.windowMs === 100 ? '<option value="100">100 ms</option>' : ''}<option value="1000">1 秒</option></select></div>` : '';
  const streams = r.raw.streams,
    videos = streams.filter((s) => s.codec_type === "video");
  if (!clean($("#file").value) || clean($("#file").value) === r.file) {
    infoPath = r.file;
    hasVideo = !!videos.length;
    $("#file").value = r.file;
    $("#stream").innerHTML = videos
      .map(
        (s) =>
          `<option value="${s.index}">${s.index} · ${esc(s.codec_name)} · ${s.width} × ${s.height}</option>`,
      )
      .join("");
    if (r.stream !== undefined) $("#stream").value = r.stream;
    $("#analyze").disabled = !hasVideo;
  }
  if (!$("#trial-file").value) {
    $("#trial-file").value = r.file;
    $("#trial-stream").value = r.stream ?? videos[0]?.index ?? 0;
  }
  cards([]);
  let html = basicInfoHTML(r);
  if (r.frames) {
    const gops = r.coding?.gops || legacyGops(r.frames);
    html += `<div class="cards">${cardsHTML([
      ["显示帧数", r.frames.length],
      ["视频包数据量", size(r.packets.bytes)],
      ["GOP / 关键帧区间", gops.length],
      ["非递增时间戳", r.summary.nonIncreasing],
    ])}</div>`;
    html += section(
      "帧结构与 GOP",
      `<p class="hint">显示顺序视图。I / P / B 是预测类型；IDR / CRA / BLA 是码流访问类型，二者不混用。GOP 以随机访问/关键帧区间呈现，不据此猜测开放或闭合。</p><div class="row"><label for="frame-axis">大小图横轴</label><select id="frame-axis"><option value="time">呈现时间（s）</option><option value="frame">显示帧序号</option></select><button id="frame-full" class="secondary">查看全片</button></div><p class="hint" id="frame-axis-note"></p><div id="gop-overview"></div><div class="pager"><button id="gop-prev" class="secondary">上一 GOP</button><label>GOP #<input id="gop-index" type="number" min="0" max="${gops.length - 1}" value="0"></label><button id="gop-next" class="secondary">下一 GOP</button><span id="gop-info"></span></div><div id="frame-plot"></div><div id="frame-detail" class="frame-detail"></div><details><summary>逐帧列表 / CSV</summary><div class="pager"><button id="prev" class="secondary">上一页</button><span id="page"></span><button id="next" class="secondary">下一页</button><button id="csv" class="secondary">导出帧 CSV</button></div><div id="frames"></div></details>`,
    );
    if (r.coding?.codec === "av1")
      html += section(
        "AV1 编码帧 / 显示事件",
        `<p>新编码帧 ${r.coding.counts.encoded} · 隐藏帧 ${r.coding.counts.hidden} · SHOW_EXISTING ${r.coding.counts.showExisting} · 显示事件 ${r.coding.counts.shown}</p><p class="hint">按码流编码顺序列出所有帧头事件，包含 KEY / INTER / INTRA_ONLY / SWITCH、隐藏帧和 SHOW_EXISTING。H=隐藏、S=显示已有帧、V=新帧直接显示。点击色带查看结构字段、刷新掩码与参考槽。OBU 负载字节不一定等于完整图像大小。</p><div id="av1-plot"></div><label>编码事件 #<input id="av1-index" type="number" min="0" max="${r.coding.events.length - 1}" value="0"></label><div id="av1-detail"></div>${raw(r.coding.sequences, "AV1 序列头（去重）")}`,
      );
    const audio = (r.tracks || []).filter((t) => t.type === "audio");
    if (audio.length) html += section("音轨包大小时间分布", audio.map(audioPacketHTML).join(""));
    let bitrateHTML = `<h4>${r.packets.bitrateCurve ? "视频包负载码率（PTS 归属）" : "视频码率 · 1 秒窗口（旧报告）"}</h4>${displayControl(r.packets.bitrateCurve, "bitrate-display")}${r.packets.bitrateCurve ? `<p class="hint">计算窗口 ${r.packets.bitrateCurve.windowMs} ms；整包按起始 PTS 归属，跨窗口包不拆分，首尾使用实际时长。边界归属可使恒定码率产生波动，短尾窗口偏差可能更大；不代表采样码率或传输瞬时码率。${r.packets.bitrateCurve.status === "ok" ? "" : esc(r.packets.bitrateCurve.reasons.join("；"))}</p>` : ""}<div id="bitrate"></div><p class="hint">缺少时间戳 ${r.packets.missing} 包。放大不改变统计窗口。</p>`;
    if (audio.length)
      bitrateHTML += audio
          .map(
            (t) =>
              `<h4>音轨 #${t.index} · ${esc(t.codec)} · 窗口码率</h4>${displayControl(t.bitrateCurve, `audio-${t.index}-display`)}${t.bitrateCurve ? '<p class="hint">整包按起始 PTS 归属，跨窗口包不拆分；恒定 PCM 也可能波动，短尾窗口偏差可能更大。曲线不代表采样码率或传输瞬时码率。</p>' : ''}<div id="audio-${t.index}"></div>${t.bitrateCurve?.status === "unavailable" ? `<p class="hint">不可计算：${esc(t.bitrateCurve.reasons.join("；"))}</p>` : ""}`,
          )
          .join("");
    html += section("音视频码率统计（可选曲线）", table(["轨道", "全程平均（原有独立口径）"], [[`视频 #${r.stream}`, rate(r.packets.averageMbps)], ...audio.map(t => [`音轨 #${t.index} · ${t.codec}`, t.averageMbps == null ? "不可计算" : rate(t.averageMbps)])]) + `<details id="bitrate-optional"><summary>展开音视频窗口码率曲线</summary>${bitrateHTML}</details>`);
    if (r.tracks)
      html += section(
        "体积构成",
        table(
          ["轨道", "压缩包数据量", "占文件比例", "包数"],
          r.tracks
            .map((t) => [
              `#${t.index} ${t.type} / ${t.codec}`,
              size(t.bytes),
              `${fmt((t.bytes / r.size) * 100)}%`,
              t.count,
            ])
            .concat([["容器及未归属差额", size(r.overheadBytes), "—", "—"]]),
        ) +
          '<p class="hint">差额按文件大小减去所有轨道包大小计算；特殊容器的重复引用可能使其为负，不等同于精确 box 大小。PCM 多音轨的体积不能算作视频可压缩空间。</p>',
      );
    if (r.content?.available) {
      const e = r.content.execution,
        execution = e
          ? `<p class="hint">SI/TI 计算设备：${e.device === "gpu" ? `GPU · ${esc(e.gpuName)} · ${esc(e.backend)}；软件解码；数值自检通过` : `CPU · ${e.mode === "frame-parallel" ? `${e.workers} 路帧级并行` : "串行"}；设置 ${e.setting === "auto" ? `自动（请求上限 ${e.requestedWorkers} 路）` : `上限 ${e.requestedWorkers} 路`}`}${e.gpuFallbackReason ? `；GPU 已回退 CPU：${esc(e.gpuFallbackReason)}` : ""}${e.fallbackReason ? `；已回退：${esc(e.fallbackReason)}` : ""}。</p>`
          : "";
      html += section(
        "SI/TI 内容复杂度",
        execution +
          table(
            ["指标", "均值", "P95", "最大值"],
            [
              [
                "SI / 空间细节",
                fmt(r.content.si.mean),
                fmt(r.content.si.p95),
                fmt(r.content.si.max),
              ],
              [
                "TI / 帧间变化",
                fmt(r.content.ti?.mean),
                fmt(r.content.ti?.p95),
                fmt(r.content.ti?.max),
              ],
            ],
          ) +
          `<h4>SI</h4><div id="si"></div><h4>TI</h4><div id="ti"></div>` +
          notices(r.content.notes),
      );
    } else if (r.content) html += notices([r.content.reason]);
    html += notices(r.warnings);
  }
  $("#details").innerHTML = html;
  initBasicInfo($("#details"), r);
  if (r.frames) {
    if (r.frames.length) initFrames(r);
    else $("#gop-overview").textContent = "报告中没有显示帧";
    initAudioPackets(r);
    const bitratePlots = new Map();
    for (const [id, t] of [["bitrate", r.packets], ...(r.tracks || []).filter(t => t.type === "audio").map(t => ["audio-" + t.index, t])]) {
      const control = $("#" + (id === "bitrate" ? "bitrate-display" : id + "-display"));
      const drawBitrate = () => {
        const windowMs = Number(control?.value ?? 1000);
        const data = t.bitrateCurve ? bitrateView(t.bitrateCurve, windowMs).map(b => [b.start, b.mbps * 1e6, b]) : t.bins.map(b => [b.second, b.mbps * 1e6, {...b, start: b.second, end: b.second + 1}]);
        const scale = quantityScale(data.map(p => p[1]), 'bit/s');
        const previous = bitratePlots.get(id);
        previous?.dispose?.();
        if (previous) { const i = charts.indexOf(previous); if (i >= 0) charts.splice(i, 1); }
        bitratePlots.set(id, draw(id, scalePlotData(data, {y: scale}), {unit: scale.unit, intervals: true, describe: p => `[${quantityNumber(p[2].start, 6)}, ${quantityNumber(p[2].end, 6)}) s · ${formatBitrate(p[2].mbps * 1e6)}${p[2].bytes == null ? '' : ` · ${p[2].bytes} B`}`}));
        if (t.bitrateCurve?.status === "unavailable") $("#" + id).textContent = "不可计算";
      };
      drawBitrate();
      if (control) control.onchange = drawBitrate;
    }
    if (r.content?.available) {
      draw(
        "si",
        r.content.points.map((p) => [p.t, p.si]),
        { unit: "SI" },
      );
      draw(
        "ti",
        r.content.points.map((p) => [p.t, p.ti]),
        { unit: "TI" },
      );
    }
  }
}
function legacyGops(frames) {
  const starts = frames
    .map((f, i) => (i === 0 || f.key ? i : null))
    .filter((x) => x !== null);
  return starts.map((start, i) => ({
    index: i,
    start,
    end: (starts[i + 1] ?? frames.length) - 1,
    count: (starts[i + 1] ?? frames.length) - start,
    label: frames[start].key ? "KEY_FLAG" : "前置片段",
  }));
}
function audioPacketHTML(track) {
  const d = track.packetDistribution, id = `audio-packets-${track.index}`;
  const title = `<h4>音轨 #${track.index} · ${esc(track.codec)}</h4>`;
  if (!d) return title + '<p class="hint">此旧报告未保存音轨逐包数据，无法从窗口码率还原；原有码率仍可展开查看。</p>';
  if (d.status !== 'ok') return title + `<p class="hint">${esc(d.reason)}</p>`;
  return title + `<p class="hint">${d.count.toLocaleString()} 个解复用包；按包起始 PTS 展示负载大小，不按持续时间摊分。包大小也受分包时长影响。单位按整条音轨选择；密集时同一像素列保留最大高度，放大或查看列表可逐包核对。</p><p class="hint" id="${id}-status"></p><div id="${id}"></div><div id="${id}-detail" class="frame-detail"></div><details><summary>音轨 #${track.index} 逐包列表 / CSV</summary><div class="pager"><button id="${id}-prev" class="secondary">上一页</button><span id="${id}-page"></span><button id="${id}-next" class="secondary">下一页</button><button id="${id}-csv" class="secondary">导出音轨包 CSV</button></div><div id="${id}-list"></div></details>`;
}
function initAudioPackets(r) {
  for (const track of (r.tracks || []).filter(t => t.type === 'audio' && t.packetDistribution?.status === 'ok')) {
    const d = track.packetDistribution, id = `audio-packets-${track.index}`, points = audioPacketPoints(d),
      scale = quantityScale(d.packets.map(row => row[3]));
    const seconds = ticks => packetSeconds(ticks, d.timeBase);
    const fields = (row, index) => [index, seconds(row[0]) == null ? '未报告' : `${quantityNumber(seconds(row[0]), 6)} s`, seconds(row[1]) == null ? '未报告' : `${quantityNumber(seconds(row[1]), 6)} s`, seconds(row[2]) > 0 ? `${quantityNumber(seconds(row[2]), 6)} s` : '未知或非正', size(row[3]), row[0] ?? '未报告', row[1] ?? '未报告', row[2] ?? '未报告'];
    const headers = ['包序号', '呈现时间', '解码时间', '持续时间', '包大小', '原始 PTS', '原始 DTS', '原始 duration'];
    const missing = d.count - points.length;
    $(`#${id}-status`).textContent = `时间基 ${d.timeBase ?? '未报告'}；${missing ? `${missing} 个包缺少有效 PTS 或时间基，仅在逐包列表中保留，不回退 DTS。` : '全部包都有可定位的呈现时间。'}`;
    draw(id, scalePlotData(points, {y: scale}), {unit: `包大小（${scale.unit}）`, axis: '呈现时间 s', stems: true,
      describe: p => `包 ${p[2].index} · PTS ${quantityNumber(p[0], 6)} s · ${formatBytes(p[2].row[3])} · ${byteEvidence(p[2].row[3])}`,
      onPick: p => {$(`#${id}-detail`).innerHTML = table(headers, [fields(p[2].row, p[2].index)]);}
    });
    if (d.packets.length) $(`#${id}-detail`).innerHTML = table(headers, [fields(d.packets[0], 0)]);
    let page = 0;
    const drawPage = () => {
      $(`#${id}-page`).textContent = `${page + 1} / ${Math.max(1, Math.ceil(d.count / 100))}`;
      $(`#${id}-prev`).disabled = page === 0;
      $(`#${id}-next`).disabled = (page + 1) * 100 >= d.count;
      $(`#${id}-list`).innerHTML = table(headers, d.packets.slice(page * 100, page * 100 + 100).map((row, i) => fields(row, page * 100 + i)));
    };
    $(`#${id}-prev`).onclick = () => {page--;drawPage();};
    $(`#${id}-next`).onclick = () => {page++;drawPage();};
    $(`#${id}-csv`).onclick = () => download('packet,pts_tick,dts_tick,duration_tick,size_bytes,time_base,pts_s,dts_s,duration_s\n' + d.packets.map((row, i) => [i, ...row, d.timeBase, ...row.slice(0, 3).map(seconds)].join(',')).join('\n'), `audio-${track.index}-packets.csv`, 'text/csv');
    drawPage();
  }
}
function initFrames(r) {
  const gops = r.coding?.gops || legacyGops(r.frames),
    frameScale = quantityScale(r.frames.map(f => f.bytes)),
    fdata = r.frames.map((f, i) => [i, f.bytes == null ? null : f.bytes / frameScale.divisor, f, i]),
    tdata = frameTimePoints(r.frames).map(p => [p[0], p[1] == null ? null : p[1] / frameScale.divisor, p[2], p[3]]);
  const detail = (p) => {
    const f = p[2],
      packet = r.coding?.packets?.[f.packetIndex];
    $("#frame-detail").innerHTML =
      table(
        ["显示帧", "时间", "预测类型", "访问类型", "关键帧标记", "包体积"],
        [
          [
            p[3],
            `${fmt(f.t, 6)} s`,
            f.type,
            f.special ?? "旧版未解析",
            f.key ? "是" : "否",
            size(f.bytes),
          ],
        ],
      ) + raw(packet ?? f, "码流包 / 单帧证据");
  };
  let ribbon, selected = 0, fullView = true;
  const axisPicker = $("#frame-axis");
  const drawFrames = () => {
    if (ribbon) {ribbon.dispose?.();const index = charts.indexOf(ribbon);if (index >= 0) charts.splice(index, 1);}
    const time = axisPicker.value === 'time', g = gops[selected],
      range = time ? frameTimeRange(r.frames, ...(fullView ? [] : [g.start, g.end])) : fullView ? [0, r.frames.length] : [g.start, g.end + 1];
    $("#frame-axis-note").textContent = time ? `显示帧关联包大小；时间取解码器报告／推定的显示时间，不按帧率估算。每帧一根竖线，密集时同一像素列保留最大高度；包与帧不保证一一对应。${tdata.length < r.frames.length ? ` ${r.frames.length - tdata.length} 帧缺少有效时间，仅在帧序号视图中保留。` : ''}` : '沿用显示帧序号与解码器报告的关联包大小；不据此重复相加估算轨道体积。';
    ribbon = draw("frame-plot", time ? tdata : fdata, {
      unit: `关联包大小（${frameScale.unit}）`, axis: time ? '呈现时间 s' : '显示帧', frames: !time, stems: time,
      xEnd: time ? frameTimeRange(r.frames)?.[1] : undefined, initial: range ?? undefined,
      onPick: detail,
      describe: p => `帧 ${p[3]} · ${fmt(p[2].t, 6)} s · ${p[2].type} / ${p[2].special ?? "未解析"} · ${formatBytes(p[2].bytes)}`,
    });
    const reset = $("#frame-plot [data-op=reset]");
    if (reset) {const original = reset.onclick;reset.onclick = () => {fullView = true;original();};}
  };
  const overview = gopOverview($("#gop-overview"), gops, r.frames.length, (i) =>
    select(i),
  );
  charts.push(overview);
  const select = (i, focus = true) => {
    selected = Math.max(0, Math.min(gops.length - 1, Math.round(i) || 0));
    const g = gops[selected];
    $("#gop-index").value = selected;
    $("#gop-info").textContent =
      `${g.label} · 帧 ${g.start}–${g.end} · ${g.count} 帧${g.boundary ? " · " + g.boundary : ""}`;
    $("#gop-prev").disabled = selected === 0;
    $("#gop-next").disabled = selected === gops.length - 1;
    if (focus) {fullView = false;drawFrames();}
    overview.select(selected);
    detail(fdata[g.start]);
  };
  $("#gop-prev").onclick = () => select(selected - 1);
  $("#gop-next").onclick = () => select(selected + 1);
  $("#gop-index").onchange = (e) => select(Number(e.target.value));
  select(0, false);
  drawFrames();
  axisPicker.onchange = drawFrames;
  $("#frame-full").onclick = () => {fullView = true;drawFrames();};
  let page = 0;
  const drawPage = () => {
    $("#page").textContent =
      `${page + 1} / ${Math.ceil(r.frames.length / 100)}`;
    $("#prev").disabled = page === 0;
    $("#next").disabled = (page + 1) * 100 >= r.frames.length;
    $("#frames").innerHTML = table(
      ["帧", "时间 s", "预测类型", "码流访问类型", "关键帧", "包体积"],
      r.frames
        .slice(page * 100, page * 100 + 100)
        .map((f, i) => [
          page * 100 + i,
          f.t,
          f.type,
          f.special ?? "未解析",
          f.key ? "是" : "否",
          size(f.bytes),
        ]),
    );
  };
  $("#prev").onclick = () => {
    page--;
    drawPage();
  };
  $("#next").onclick = () => {
    page++;
    drawPage();
  };
  $("#csv").onclick = () =>
    download(
      "frame,time_s,prediction,access_type,key,packet_bytes,duration_s\n" +
        r.frames
          .map((f, i) =>
            [
              i,
              f.t,
              f.type,
              f.special ?? "",
              f.key ? 1 : 0,
              f.bytes,
              f.duration,
            ].join(","),
          )
          .join("\n"),
      "frames.csv",
      "text/csv",
    );
  drawPage();
  if (r.coding?.codec === "av1") {
    const events = r.coding.events,
      eventScale = quantityScale(events.map(e => e.obuPayloadBytes));
    const eventDetail = (p) => {
      const e = events[p[0]];
      $("#av1-index").value = e.id;
      $("#av1-detail").innerHTML =
        table(
          [
            "事件 / 编码包",
            "类型 / 可见性",
            "显示帧",
            "Order hint",
            "刷新掩码",
            "引用槽 → 编码事件",
          ],
          [
            [
              `${e.id} / ${e.packet}`,
              `${e.kind} / ${e.hidden ? "隐藏" : "显示"}`,
              e.displayIndex ?? "不直接输出",
              e.orderHint,
              e.refreshFlags == null
                ? "未报告"
                : "0x" + e.refreshFlags.toString(16),
              e.showExisting
                ? `显示槽 ${e.showSlot} → 事件 ${e.sourceEvent ?? "未知"}`
                : (e.referenceSlots || [])
                    .map((s, i) => `${s}→${e.referenceEvents?.[i] ?? "未知"}`)
                    .join(", "),
            ],
          ],
        ) + raw(e, "结构相关帧头字段与引用证据");
    };
    draw(
      "av1-plot",
      events.map((e) => [
        e.id,
        e.obuPayloadBytes == null ? null : e.obuPayloadBytes / eventScale.divisor,
        {
          type: e.hidden ? "H" : e.showExisting ? "S" : "V",
          special: e.kind,
          key: e.kind === "KEY",
        },
      ]),
      {
        unit: `OBU 负载体积（${eventScale.unit}）`,
        axis: "编码事件",
        frames: true,
        initial: [0, Math.min(60, Math.max(1, events.length))],
        onPick: eventDetail,
        describe: (p) => {
          const e = events[p[0]];
          return `事件 ${e.id} · 包 ${e.packet} · ${e.kind} · ${e.hidden ? "隐藏" : "显示"} · order_hint ${e.orderHint ?? "未知"} · ${formatBytes(e.obuPayloadBytes)}`;
        },
      },
    );
    if (events.length) eventDetail([0]);
    $("#av1-index").onchange = (e) =>
      eventDetail([
        Math.max(
          0,
          Math.min(events.length - 1, Math.round(Number(e.target.value)) || 0),
        ),
      ]);
  }
}
function renderComparison(r) {
  cards([
    ["参考文件", size(r.reference.size)],
    ["候选文件", size(r.candidate.size)],
    ["总文件体积比", `${fmt(r.sizeRatio * 100)}%`],
    [
      r.alignment.pairing === "playback-sample" ? "采样时刻" : "匹配显示帧",
      r.alignment.frames,
    ],
  ]);
  let html =
    `<p class="path">参考：${esc(r.reference.file)}<br>候选：${esc(r.candidate.file)}</p>` +
    notices([r.alignment.note]);
  if (r.alignment.pairing === "ordinal-confirmed")
    html += section(
      "帧序配对与时间轴差异",
      table(
        [
          "配对方式",
          "首次超过 0.1 ms 的帧",
          "最大相对时间差",
          "末帧持续时间差",
        ],
        [
          [
            "解码显示帧序号",
            r.alignment.firstTimestampMismatchFrame ?? "未超过",
            `${fmt(r.alignment.maxRelativeDifferenceSeconds * 1000, 3)} ms`,
            r.alignment.lastDurationDifferenceSeconds == null
              ? "未报告"
              : `${fmt(r.alignment.lastDurationDifferenceSeconds * 1000, 3)} ms`,
          ],
        ],
      ) +
        notices([
          "时间轴差异已记录；指标按对应帧计算，不代表两路播放时间完全一致。",
        ]),
    );
  if (r.alignment.pairing === "playback-sample") {
    const a = r.alignment,
      modern = !!a.gridSide;
    html += section(
      "VFR ↔ CFR 播放采样 · 实验性",
      table(
        [
          "CFR 网格所在视频 / 帧率",
          "采样视频帧 / 网格帧",
          "CFR 最大偏差 / 容差",
          "采样重复 / 未采样帧（估计）",
        ],
        [
          [
            `${modern ? (a.gridSide === "reference" ? "参考" : "候选") : "候选"} / ${modern ? a.gridRate : a.candidateRate} (${fmt(modern ? a.gridRateHz : a.candidateRateHz, 3)} fps)`,
            `${fmt(modern ? a.sampledFrames : a.sourceFrames)} / ${fmt(a.frames)}`,
            `${fmt((modern ? a.maxGridErrorSeconds : a.maxCandidateGridErrorSeconds) * 1000, 4)} / ${fmt(a.cfrToleranceSeconds * 1000, 4)} ms`,
            `${fmt(a.estimatedRepeatedSamples)} / ${fmt(modern ? a.estimatedUnrepresentedSampledFrames : a.estimatedUnrepresentedSourceFrames)}`,
          ],
        ],
      ) +
        notices([
          a.sampling,
          a.note,
          "两路首帧对应同一播放时刻由用户确认。指标只覆盖 CFR 网格的采样时刻；完整的估计帧索引映射保存在导出的 JSON 中。",
        ]),
    );
  }
  if (r.chromaAssumptions?.length)
    html += section(
      "用户确认的色度位置",
      table(
        ["视频", "文件报告值", "本次采用值", "证据性质"],
        r.chromaAssumptions.map((x) => [
          x.side === "reference" ? "参考" : "候选",
          x.declared ?? "未报告",
          x.assumed,
          x.source,
        ]),
      ) + notices(["该位置由用户指定，软件未验证其真实性；指标依赖此假设。"]),
    );
  if (r.profile)
    html += section(
      "比较域与格式",
      table(
        ["像素格式", "位深 / 采样", "信号", "原色 / 传递 / 矩阵 / 范围"],
        [
          [
            r.profile.pixelFormat,
            `${r.profile.bitDepth}-bit / ${r.profile.subsampling}`,
            r.profile.signal,
            `${r.profile.primaries} / ${r.profile.transfer} / ${r.profile.matrix} / ${r.profile.range}`,
          ],
        ],
      ) + notices([r.profile.domain]),
    );
  if (r.normalization?.crossDepth)
    html += section(
      "跨位深码值映射",
      table(
        ["参考原格式", "候选原格式", "比较格式", "映射 / PSNR 峰值"],
        [
          [
            r.normalization.sourceFormats.reference,
            r.normalization.sourceFormats.candidate,
            r.normalization.targetFormat,
            `${r.normalization.mapping} / ${r.normalization.psnrPeak}`,
          ],
        ],
      ) +
        notices([
          r.normalization.basis,
          r.normalization.verification?.passed
            ? "本机全码值映射校验通过（Y / Cb / Cr，0–255）"
            : "未报告映射验证",
        ]) +
        raw(r.normalization),
    );
  if (r.skippedMetrics)
    html += notices(
      Object.entries(r.skippedMetrics).map(
        ([k, v]) => `${k.toUpperCase()} 未计算：${v}`,
      ),
    );
  for (const [key, m] of Object.entries(r.metrics))
    if (m.components)
      html += section(
        `${key.toUpperCase()} 分量`,
        table(
          Object.keys(m.components).map(k=>({y:r.profile?.colorModel==='GRAY'?'Y 灰度':'Y 亮度',u:'U 色度',v:'V 色度',r:'R 红',g:'G 绿',b:'B 蓝',a:'A 透明度'})[k]??k.toUpperCase()),
          [Object.values(m.components).map(v=>fmt(v,m.officialSummary?6:5))],
        ),
      );
  if (r.videoSize)
    html += section(
      "仅视频数据量",
      table(
        ["参考视频包", "候选视频包", "候选 / 参考"],
        [
          [
            size(r.videoSize.reference),
            size(r.videoSize.candidate),
            `${fmt((r.videoSize.candidate / r.videoSize.reference) * 100)}%`,
          ],
        ],
      ) +
        '<p class="hint">此比例排除了音轨与容器体积，便于评价视频编码的实际节省。</p>',
    );
  for (const [key, m] of Object.entries(r.metrics))
    html += section(
      key.toUpperCase(),
      table(
        ["整体值", "P05", "最低帧", "统计方式"],
        [
          [
            fmt(m.pooled, key!=='vmaf'&&m.officialSummary?6:5),
            fmt(m.p05, 5),
            fmt(m.min, 5),
            key === "psnr"
              ? "MSE 域汇总 / dB"
              : key === "vmaf"
                ? m.model
                : "逐帧均值",
          ],
        ],
      ) +
        (key==='vmaf'?vmafDetails(m):'') +
        `<div id="metric-${key}"></div>` +
        (m.worst
          ? "<h4>最低质量的 1 秒区间（相对参考起点）</h4>" +
            table(
              ["起点 / 秒", "帧范围", "区间整体值", "最低帧值"],
              m.worst.map((w) => [
                w.start,
                `${w.first}–${w.last}`,
                fmt(w.value, 5),
                fmt(w.min, 5),
              ]),
            )
          : "") +
        '<p class="hint">最低区间用于定位复查，不自动判定画面不可接受。末尾区间可能不足 1 秒。</p>',
    );
  const alignmentEvidence = { ...r.alignment };
  delete alignmentEvidence.estimatedSourceFrameIndices;
  delete alignmentEvidence.estimatedSampledFrameIndices;
  html +=
    notices(r.warnings) +
    section(
      "复现记录",
      raw({
        tools: r.tools,
        commands: r.commands,
        alignment: alignmentEvidence,
      }),
    );
  $("#details").innerHTML = html;
  for (const [k, m] of Object.entries(r.metrics))
    draw(
      "metric-" + k,
      m.values.map((v, i) => [i, v === "Infinity" ? null : v]),
      { unit: metricLabels[k], axis: "显示帧序号（从 0 开始）" },
    );
}
function vmafDetails(m) {
  const c=m.configuration;
  return c?table(['官方模型','输入','汇总 / 采样','libvmaf 版本'],[[c.model.version,`${c.input.width}×${c.input.height} · ${c.input.pixelFormat} · ${c.input.range==='pc'?'Full':c.input.range==='tv'?'Limited':'范围未声明'}`,`${c.pool} / 每 ${c.nSubsample} 帧`,c.libraryVersion]])+
    notices([c.interpretation,'VMAF 评价亮度；不衡量色度损失。整体值采用 libvmaf 官方汇总；P05 和最低 1 秒区间是本软件的定位统计。'])+
    '<details><summary>VMAF 参数与输入记录</summary>'+raw(c)+'</details>':'';
}
function renderTrial(r) {
  cards([
    ["片段起点", `${r.experiment.start} s`],
    ["请求片段长度", `${r.experiment.duration} s`],
    ["实际显示帧", r.experiment.actualFrames],
    ["编码器", r.experiment.encoder],
  ]);
  const rows = r.rows.map((x) => ({
      ...x,
      preset: x.preset ?? r.experiment.preset,
    })),
    groups = [...new Set(rows.map(rowLabel))],
    metrics = ["psnr", "ssim", "vmaf"].filter((m) =>
      rows.some((x) => x.metrics[m]),
    );
  const byteScale = quantityScale(rows.map(x => x.videoBytes)),
    bitScale = quantityScale(rows.map(x => x.videoMbps == null ? null : x.videoMbps * 1e6), 'bit/s'),
    scales = {videoBytes: byteScale, videoMbps: {...bitScale, divisor: bitScale.divisor / 1e6}};
  let html =
    `<p class="path">${esc(r.source.file)}</p>` +
    notices([
      r.experiment.comparisonDomain ?? "原生位深参考",
      ...Object.values(r.skippedMetrics ?? {}),
    ]);
  if(rows[0]?.metrics.vmaf)html+=section('VMAF 模型与适用条件',vmafDetails(rows[0].metrics.vmaf));
  if (r.experiment.preparation?.baseline)
    html += section(
      "编码前的位深转换基准",
      notices([r.experiment.preparation.mapping]) +
        table(
          ["PSNR / dB", "SSIM", "含义"],
          [
            [
              fmt(r.experiment.preparation.baseline.psnr.pooled, r.experiment.preparation.baseline.psnr.officialSummary?6:5),
              fmt(r.experiment.preparation.baseline.ssim.pooled, 6),
              "两种无损输入在统一 10-bit 域的差异；尚未试编码，不与成片分数相减。",
            ],
          ],
        ),
    );
  html += section(
    "实验采样点",
    `<details id="trial-samples" ${rows.length <= 12 ? "open" : ""}><summary>查看 ${rows.length} 个实测点</summary><div class="sample-sort"><label>排序参数<select id="sample-sort-key">${Object.entries(
      trialSortFields,
    )
      .map(([k, v]) => `<option value="${k}">${esc(v)}</option>`)
      .join(
        "",
      )}</select></label><label>顺序<select id="sample-sort-direction"><option value="asc">升序</option><option value="desc">降序</option></select></label></div><div id="trial-sample-table"></div></details>`,
  );
  html += section(
    "CRF 参数扫描 · 固定每条曲线的位深与 preset",
    '<div class="trial-chart-grid"><div><h4>① CRF 与质量：PSNR（越高越好）</h4><div id="trial-psnr"></div></div><div><h4>② CRF 与编码耗时（越低越快）</h4><div id="trial-time"></div></div><div><h4>③ CRF 与视频码率（数据开销）</h4><div id="trial-rate"></div></div><div><h4>④ CRF 与质量：SSIM（越高越好）</h4><div id="trial-ssim"></div></div></div><p class="hint">每个圆点是一个 CRF 实测结果，每条线固定一个位深 / preset；连线仅辅助读图，不是拟合或插值预测。横轴 CRF 是编码器参数，无量纲；同 CRF 不保证同质量或码率。耗时仅为本机单次测量，无误差条，不宜据微小差异排名。</p>',
  );
  html += section(
    "码率—质量与编码成本",
    `<div class="two"><label>横轴<select id="rd-axis"><option value="videoMbps">视频平均码率（${bitScale.unit}）</option><option value="videoBytes">视频包体积（${byteScale.unit}）</option><option value="encodeSeconds">编码耗时（s）</option><option value="encodeFps">编码速度（frame/s）</option></select></label><label>纵轴指标<select id="rd-metric">${metrics.map((m) => `<option value="${m}">${esc(metricLabels[m])}</option>`).join("")}</select></label></div><div id="rd"></div><p class="hint">码率—质量图：同等质量时越靠左越省码率，同等码率时越高越好；需比较同一参考片段及指标域。成本图仅显示散点：相同质量下比较编码时间或速度。体积与码率仅计视频包。PSNR 为 MSE 域汇总，SSIM / VMAF 为逐帧均值。</p>`,
  );
  html += section(
    "逐帧质量叠加 · 固定位深与 preset，对比 CRF",
    `<div class="two"><label>固定对比组<select id="trial-group">${groups.map((g, i) => `<option value="${i}">${esc(g)}</option>`).join("")}</select></label><label>纵轴质量指标<select id="trial-frame-metric">${metrics.map((m) => `<option value="${m}">${esc(metricLabels[m])}</option>`).join("")}</select></label></div><div id="trial-crf-select" class="checks"></div><p id="trial-frame-note" class="hint"></p><div id="trial-frames"></div>`,
  );
  html +=
    notices(r.warnings) +
    section(
      "实验文件与复现记录",
      `<p class="hint">${r.experiment.retainedFiles.length ? "已保留实验文件：" + esc(r.experiment.retainedFiles.join("；")) : "实验视频已自动清理；报告保留数据与运行参数。"}</p>` +
        raw({ experiment: r.experiment, tools: r.tools, commands: r.commands }),
    );
  $("#details").innerHTML = html;
  const labels = {
    ...metricLabels,
    videoBytes: `视频包体积（${byteScale.unit}）`,
    videoMbps: `视频平均码率（${bitScale.unit}）`,
    encodeSeconds: "编码耗时（s）↓",
    encodeFps: "编码速度（frame/s）↑",
    crf: "CRF（无量纲）",
  };
  const drawSamples = () => {
    $("#trial-sample-table").innerHTML = table(
      [
        "位深 / preset",
        "CRF",
        "视频包体积",
        "视频码率",
        "PSNR / dB",
        "SSIM / 无量纲",
        "VMAF / 模型分数",
        "编码耗时 s / 速度 frame/s",
      ],
      sortTrialRows(
        rows,
        $("#sample-sort-key").value,
        $("#sample-sort-direction").value,
      ).map((x) => [
        rowLabel(x),
        x.crf,
        size(x.videoBytes),
        rate(x.videoMbps),
        fmt(x.metrics.psnr?.pooled,x.metrics.psnr?.officialSummary?6:3),
        fmt(x.metrics.ssim?.pooled, 6),
        fmt(x.metrics.vmaf?.pooled),
        `${fmt(x.encodeSeconds)} / ${fmt(x.encodeFps)}`,
      ]),
    );
  };
  const seriesPlot = (id, x, y) => {
    const { data, series } = trialPlotData(rows, x, y);
    return draw(id, scalePlotData(data, {x: scales[x], y: scales[y]}), {
      series,
      connect: !["encodeSeconds", "encodeFps"].includes(x),
      unit: labels[y],
      axis: labels[x],
      describe: (p) =>
        `${rowLabel(p[2])} · CRF ${p[2].crf} · ${labels[x]} ${quantityNumber(p[0], 6)} · ${labels[y]} ${["psnr", "ssim", "vmaf"].includes(y) ? fmt(p[2].metrics[y]?.pooled, 6) : quantityNumber(p[1], 6)} · ${formatBytes(p[2].videoBytes)} · ${rate(p[2].videoMbps)}`,
    });
  };
  seriesPlot("trial-psnr", "crf", "psnr");
  seriesPlot("trial-time", "crf", "encodeSeconds");
  seriesPlot("trial-rate", "crf", "videoMbps");
  seriesPlot("trial-ssim", "crf", "ssim");
  let rd, framePlot;
  const update = () => {
    rd?.dispose();
    rd = seriesPlot("rd", $("#rd-axis").value, $("#rd-metric").value);
  };
  let selectedCrfs = [];
  const updateFrames = () => {
    framePlot?.dispose();
    const group = groups[Number($("#trial-group").value) || 0],
      metric = $("#trial-frame-metric").value || metrics[0];
    const result = trialFramePlotData(
      rows,
      metric,
      group,
      selectedCrfs,
      r.experiment.frameTimes,
    );
    $("#trial-frame-note").textContent =
      (result.timed
        ? "横轴：相对片段首帧的时间（s），使用保存的参考帧时间戳。"
        : "横轴：片段显示帧序号（从 0 开始）；报告未保存可用时间戳，不估算秒数。") +
      " 同一参考片段、位深与 preset；仅改变 CRF。悬停可并列读取各曲线；无限值和缺失值留空，不跨空缺连线。" +
      (result.missing.length
        ? " 未保存逐帧数据的 CRF：" + result.missing.join("、")
        : "");
    if (!result.data.length) {
      $("#trial-frames").textContent = selectedCrfs.length
        ? "该报告未保存所选指标的逐帧数据。"
        : "请至少选择一个 CRF。";
      return;
    }
    framePlot = draw("trial-frames", result.data, {
      series: result.series,
      markers: false,
      height: 440,
      axis: result.timed
        ? "相对片段首帧时间（s）"
        : "片段显示帧序号（从 0 开始）",
      unit: labels[metric],
      describe: (p) =>
        "CRF " +
        p[2].crf +
        " · 帧 " +
        p[2].frame +
        " · " +
        labels[metric] +
        " " +
        (p[2].value === "Infinity"
          ? "∞"
          : p[2].value == null
            ? "缺失"
            : fmt(p[2].value, 6)),
    });
  };
  const updateGroup = () => {
    selectedCrfs = rows
      .filter(
        (row) => rowLabel(row) === groups[Number($("#trial-group").value) || 0],
      )
      .map((row) => row.crf)
      .sort((a, b) => a - b);
    $("#trial-crf-select").innerHTML = selectedCrfs
      .map(
        (crf) =>
          '<label><input type="checkbox" name="plot-crf" value="' +
          crf +
          '" checked>CRF ' +
          crf +
          "</label>",
      )
      .join("");
    document.querySelectorAll("[name=plot-crf]").forEach(
      (box) =>
        (box.onchange = () => {
          selectedCrfs = [
            ...document.querySelectorAll("[name=plot-crf]:checked"),
          ].map((x) => Number(x.value));
          updateFrames();
        }),
    );
    updateFrames();
  };
  $("#sample-sort-key").onchange = drawSamples;
  $("#sample-sort-direction").onchange = drawSamples;
  $("#rd-axis").onchange = update;
  $("#rd-metric").onchange = update;
  $("#trial-group").onchange = updateGroup;
  $("#trial-frame-metric").onchange = updateFrames;
  drawSamples();
  update();
  updateGroup();
}
api("status")
  .then((s) => {
    showStartup(s);
    poll();
  })
  .catch((e) => message(e.message, true));

// 1. Dynamic Floating Nav
nav = document.createElement("aside");
nav.className = "floating-nav";
document.body.appendChild(nav);

function updateNav() {
  if (!nav) return;
  const items = document.createDocumentFragment();
  const visiblePanels = Array.from(
    document.querySelectorAll(
      ".panel:not(.hidden), #inspect-result:not(.hidden), #compare-result:not(.hidden), #trial-result:not(.hidden)",
    ),
  );

  let hasItems = false;
  visiblePanels.forEach((panel) => {
    const titleEls = panel.querySelectorAll("h2, h3");
    titleEls.forEach((titleEl, index) => {
      if (!titleEl.id) {
        titleEl.id = panel.id + "-heading-" + index;
      }
      const a = document.createElement("a");
      a.href = "#" + titleEl.id;
      a.className = "nav-dot";
      const label = document.createElement("span");
      label.textContent = titleEl.textContent;
      a.appendChild(label);
      items.appendChild(a);
      hasItems = true;
    });
  });
  nav.replaceChildren(items);
  nav.style.display = hasItems ? "flex" : "none";
}

updateNav();

// switchMode runs after synchronous and asynchronous report rendering and import.

function syncTaskBrief() {
  const task = document.getElementById("task"),
    brief = document.getElementById("island-brief-text"),
    queueCount = document.getElementById("queue-count"),
    compactCount = document.getElementById("island-q-count");
  if (queueCount && compactCount)
    compactCount.textContent = queueCount.textContent || "0";
  if (!task || !brief) return;
  if (task.classList.contains("hidden")) {
    brief.textContent = "当前无任务";
    return;
  }
  const label = document.getElementById("task-label"),
    phase = document.getElementById("task-phase");
  brief.textContent = [
    label?.textContent,
    phase && !phase.classList.contains("hidden") ? phase.textContent : "",
  ].filter(Boolean).join(" ") || "运行中...";
}

// 2. 任务队列（通栏 / 紧凑悬浮视图）
const taskEl = document.getElementById("task");
if (taskEl) {
  taskEl.removeAttribute("onclick"); // Clean old attribute

  const header = document.createElement("div");
  header.className = "island-header";
  header.innerHTML = `
          <div class="island-brief">
            <div class="pulse-dot"></div>
            <span id="island-brief-text">当前无任务</span>
          </div>
          <div class="island-queue">排队: <span id="island-q-count">0</span></div>
          <div class="island-progress-track"><div id="island-progress-bar"></div></div>
        `;
  // Toggle expansion
  header.onclick = () => {
    if (taskEl.classList.contains("island")) {
      taskEl.classList.toggle("expanded");
    }
  };
  taskEl.insertBefore(header, taskEl.firstChild);

  const toggleBtn = document.getElementById("toggle-island");
  if (toggleBtn) {
    toggleBtn.onclick = (e) => {
      e.stopPropagation();
      if (taskEl.classList.contains("task-banner")) {
        taskEl.classList.remove("task-banner");
        taskEl.classList.add("island");
        toggleBtn.innerHTML =
          '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="15 3 21 3 21 9"></polyline><polyline points="9 21 3 21 3 15"></polyline><line x1="21" y1="3" x2="14" y2="10"></line><line x1="3" y1="21" x2="10" y2="14"></line></svg>';
        toggleBtn.title = "还原为顶部视图";
      } else {
        taskEl.classList.remove("island");
        taskEl.classList.remove("expanded");
        taskEl.classList.add("task-banner");
        toggleBtn.innerHTML =
          '<svg viewBox="0 0 24 24" width="16" height="16" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><polyline points="4 14 10 14 10 20"></polyline><polyline points="20 10 14 10 14 4"></polyline><line x1="14" y1="10" x2="21" y2="3"></line><line x1="3" y1="21" x2="10" y2="14"></line></svg>';
        toggleBtn.title = "切换到紧凑视图";
      }
      taskEl.classList.remove('tucked');
      taskEl.style.removeProperty('left');
      taskEl.style.removeProperty('top');
      taskEl.style.removeProperty('right');
      taskEl.style.removeProperty('bottom');
      taskEl.style.removeProperty('position');
      taskEl.style.removeProperty('margin');
      taskEl.style.removeProperty('transition');
    };
  }

  let isDragging = false;
  let startX, startY, initialLeft, initialTop;
  let snapEnabled = true;
  let hasDragged = false;

  const snapBtn = document.getElementById("toggle-snap");
  if (snapBtn) {
    snapBtn.onclick = (e) => {
      e.stopPropagation();
      snapEnabled = !snapEnabled;
      snapBtn.classList.toggle("active", snapEnabled);
      if (snapEnabled && !isDragging) {
         snapToEdge();
      }
    };
  }

  function snapToEdge() {
    if (!snapEnabled) return;

    const rect = taskEl.getBoundingClientRect();
    const vWidth = document.documentElement.clientWidth;
    const vHeight = document.documentElement.clientHeight;
    const centerX = rect.left + rect.width / 2;

    let targetLeft;
    let targetTop = rect.top;
    const edgeMargin = 20; // Keep a small margin from the edge

    // Only snap left or right
    if (centerX < vWidth / 2) {
      targetLeft = edgeMargin;
    } else {
      targetLeft = vWidth - rect.width - edgeMargin;
    }

    // Keep vertical position within viewport
    targetTop = Math.max(edgeMargin, Math.min(targetTop, vHeight - rect.height - edgeMargin));

    taskEl.style.position = 'fixed';
    taskEl.style.setProperty('right', 'auto', 'important');
    taskEl.style.setProperty('bottom', 'auto', 'important');
    taskEl.style.margin = '0';
    taskEl.style.transition = 'left 0.3s ease, top 0.3s ease';
    
    // Slide to the target position
    taskEl.style.setProperty('left', targetLeft + 'px', 'important');
    taskEl.style.setProperty('top', targetTop + 'px', 'important');
    
    setTimeout(() => { taskEl.style.transition = ''; }, 300);
  }

  taskEl.onmousedown = (e) => {
    if (e.button !== 0) return;
    const target = e.target;
    if (target.closest('button') || target.closest('input') || target.closest('select')) return;

    startX = e.clientX;
    startY = e.clientY;
    isDragging = false;
    hasDragged = false;
    
    document.addEventListener('mousemove', onMouseMove);
    document.addEventListener('mouseup', onMouseUp);
  };

  function onMouseMove(e) {
    const dx = e.clientX - startX;
    const dy = e.clientY - startY;

    if (!isDragging) {
      if (Math.abs(dx) > 5 || Math.abs(dy) > 5) {
        isDragging = true;
        hasDragged = true;
        const rect = taskEl.getBoundingClientRect();
        initialLeft = rect.left;
        initialTop = rect.top;

        taskEl.style.position = 'fixed';
        taskEl.style.setProperty('left', initialLeft + 'px', 'important');
        taskEl.style.setProperty('top', initialTop + 'px', 'important');
        taskEl.style.setProperty('right', 'auto', 'important');
        taskEl.style.setProperty('bottom', 'auto', 'important');
        taskEl.style.margin = '0';
        taskEl.style.transition = 'none';
      } else {
        return;
      }
    }

    taskEl.style.setProperty('left', (initialLeft + dx) + 'px', 'important');
    taskEl.style.setProperty('top', (initialTop + dy) + 'px', 'important');
  }

  function onMouseUp() {
    document.removeEventListener('mousemove', onMouseMove);
    document.removeEventListener('mouseup', onMouseUp);
    
    if (hasDragged && snapEnabled) {
      setTimeout(snapToEdge, 50);
    }
    isDragging = false;
    hasDragged = false;
  }

  syncTaskBrief();
  setInterval(syncTaskBrief, 300);
}

const themeToggleBtn = document.getElementById("theme-toggle");
if (themeToggleBtn) {
  const states = ["system", "light", "dark"];
  const icons = {
    system: document.getElementById("theme-icon-system"),
    light: document.getElementById("theme-icon-light"),
    dark: document.getElementById("theme-icon-dark")
  };
  
  let currentTheme = document.documentElement.getAttribute("data-theme") || "system";
  
  function applyTheme() {
    if (currentTheme === "system") {
      document.documentElement.removeAttribute("data-theme");
    } else {
      document.documentElement.setAttribute("data-theme", currentTheme);
    }
    
    for (const [key, icon] of Object.entries(icons)) {
      if (icon) icon.style.display = key === currentTheme ? "block" : "none";
    }
  }
  
  applyTheme();
  
  themeToggleBtn.onclick = () => {
    const idx = states.indexOf(currentTheme);
    currentTheme = states[(idx + 1) % states.length];
    applyTheme();
    api("local-data/settings", {method:"POST",body:JSON.stringify({theme:currentTheme})}).catch(e=>message(e.message,true));
  };
}

$("#trial-keep").onchange = () => $("#trial-save-row").classList.toggle("hidden", !$("#trial-keep").checked);
$("#trial-save-picker").onclick = async () => {
  const button=$("#trial-save-picker");button.disabled=true;
  try {const value=await api("select-directory",{method:"POST",body:"{}"});if(value.directory)$("#trial-save-directory").value=value.directory}
  catch(e){message(e.message,true)}finally{button.disabled=false}
};
async function refreshLocalData(){
  const value=await api("local-data");
  $("#clear-on-exit").checked=value.settings.clearOnExit;
  $("#local-data-usage").textContent=`近期记录 ${value.count} / ${value.limit} 次 · ${formatBytes(value.recordBytes)}；浏览器缓存 ${formatBytes(value.profileBytes)}；运行目录总计 ${formatBytes(value.totalBytes)}。${value.warnings.join('；')}`;
  $("#local-data-usage").title=`近期记录 ${byteEvidence(value.recordBytes)}；浏览器缓存 ${byteEvidence(value.profileBytes)}；运行目录总计 ${byteEvidence(value.totalBytes)}`;
}
$("#local-data-panel").ontoggle=()=>{if($("#local-data-panel").open)refreshLocalData().catch(e=>message(e.message,true))};
$("#local-data-refresh").onclick=()=>refreshLocalData().catch(e=>message(e.message,true));
$("#clear-on-exit").onchange=async()=>{
  const checkbox=$("#clear-on-exit");checkbox.disabled=true;
  try{await api("local-data/settings",{method:"POST",body:JSON.stringify({clearOnExit:checkbox.checked})})}
  catch(e){checkbox.checked=!checkbox.checked;message(e.message,true)}finally{checkbox.disabled=false}
};
for(const [id,category]of [["#local-data-clear","records"],["#local-cache-clear","cache"]])$(id).onclick=async()=>{
  if(category==='records'&&!confirm('清空本地近期记录？需要长期保留的结果请先导出 JSON。'))return;
  const button=$(id);button.disabled=true;
  try{const value=await api("local-data/clean",{method:"POST",body:JSON.stringify({category})});await poll();await refreshLocalData();message(value.message)}
  catch(e){message(e.message,true)}finally{button.disabled=false}
};
